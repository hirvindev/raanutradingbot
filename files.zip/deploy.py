"""
deploy.py — copies the correct RaanuTradingBot.html to your folder
Run this from your Downloads folder or Algo Trading folder.
It writes the file directly — no copy-paste needed.
"""
import os
import shutil
import subprocess

DEST = r"C:\Users\Archana Arjunraj\OneDrive\Desktop\Algo Trading"
FILES = [
    "RaanuTradingBot.html",
    "vercel.json",
    "README.md",
    "fix_branding.py",
]

print("=" * 50)
print("  RaanuTradingBot — Deploy Script")
print("=" * 50)

# Copy all downloaded files from Downloads to Algo Trading
downloads = os.path.expanduser(r"~\Downloads")
copied = []
for f in FILES:
    src = os.path.join(downloads, f)
    dst = os.path.join(DEST, f)
    if os.path.exists(src):
        shutil.copy2(src, dst)
        print(f"  [OK] Copied {f}")
        copied.append(f)
    else:
        print(f"  [--] {f} not in Downloads — skipping")

# Fix branding in RaanuTradingBot.html
html_path = os.path.join(DEST, "RaanuTradingBot.html")
if os.path.exists(html_path):
    with open(html_path, "r", encoding="utf-8") as fh:
        content = fh.read()
    content = content.replace("AlgoTrader v2.1 \u2014 Trade 212", "RaanuTradingBot \u2014 Trade 212")
    content = content.replace("Algo<em>Trader</em>", "Raanu<em>TradingBot</em>")
    content = content.replace("AlgoTrader v2.1 starting", "RaanuTradingBot v2.1 starting")
    with open(html_path, "w", encoding="utf-8") as fh:
        fh.write(content)
    print("  [OK] Branding fixed in RaanuTradingBot.html")

# Git add, commit, push
print()
print("  Pushing to GitHub...")
os.chdir(DEST)
subprocess.run(["git", "add", "."], check=True)
result = subprocess.run(["git", "status", "--short"], capture_output=True, text=True)
if result.stdout.strip():
    subprocess.run(["git", "commit", "-m", "Deploy: 370+ stock scanner, company names, Vercel, README, branding fix"], check=True)
    subprocess.run(["git", "push"], check=True)
    print("  [OK] Pushed to GitHub!")
    print("  [OK] Vercel will auto-deploy in ~30 seconds")
else:
    print("  [--] Nothing new to push")

print()
print("=" * 50)
print("  Done! Open https://raanutradingbot.vercel.app")
print("=" * 50)
