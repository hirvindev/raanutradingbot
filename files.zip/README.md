# 🤖 RaanuTradingBot

> Algorithmic trading bot connected to Trade 212 paper/live account with AI-powered market scanning.

[![Live Dashboard](https://img.shields.io/badge/Live%20Dashboard-raanutradingbot.vercel.app-00c896?style=for-the-badge)](https://raanutradingbot.vercel.app)
[![Trade 212](https://img.shields.io/badge/Trade%20212-Demo%20Mode-f59e0b?style=for-the-badge)](https://trading212.com)
[![Python](https://img.shields.io/badge/Python-3.10+-3b82f6?style=for-the-badge)](https://python.org)

---

## 🌐 Live URL

```
https://raanutradingbot.vercel.app
```

---

## ✨ Features

- 📊 **Real-time T212 metrics** — Portfolio value, Open P&L, Win rate, Avg trade, Stop loss hits
- 🔍 **Market Scanner** — Scans 370+ large, mid and small cap US stocks automatically
- ⚡ **Pattern Detection** — Momentum, Breakout, Uptrend, Golden Cross
- 🏆 **Top 20 Winners** — Only shows sure-shot picks, no noise
- 📈 **Indicator Engine** — RSI(14), MACD(12,26,9), Bollinger Bands(20,2σ), EMA(50/200), ATR(14)
- 🤖 **Auto Trader** — Executes trades automatically when score ≥ 60/100
- 🛡️ **Risk Management** — Auto stop loss, take profit, position sizing, circuit breaker
- 🔒 **Secure** — API key stored in `.env`, never in code

---

## 🗂️ Project Structure

```
├── server.py                  ← FastAPI backend (port 8000)
├── auto_trader.py             ← Auto-trading engine
├── strategy.py                ← Indicator + scoring engine
├── RaanuTradingBot.html       ← Dashboard (served by Vercel)
├── vercel.json                ← Vercel deployment config
├── .env                       ← API keys (not in GitHub)
├── CLAUDE.md                  ← AI context file
└── START.bat                  ← One-click launcher (Windows)
```

---

## 🚀 Quick Start

### Run locally

```bash
# Install dependencies
pip install fastapi uvicorn httpx python-dotenv pydantic numpy pandas yfinance ta

# Configure
cp .env.example .env
# Edit .env with your T212 API key

# Start
python server.py
```

Open: **http://localhost:8000**

### Deploy to Vercel

1. Fork this repo
2. Go to [vercel.com](https://vercel.com) → Import project
3. Select this repo → Deploy
4. Done ✅

---

## ⚙️ Configuration

Create a `.env` file:

```env
T212_API_KEY=your_trade212_api_key
T212_MODE=demo
SCAN_INTERVAL=900
WEEKLY_TRADE_LIMIT=2
PER_TRADE_MAX_EUR=500
MIN_SIGNAL_SCORE=60
WATCHLIST=AAPL,MSFT,NVDA,GOOGL,AMZN,META,AMD,TSLA
```

Get your API key: **Trade 212 app → Settings → API (Beta)**

---

## 📊 Dashboard Sections

| Section | Description |
|---------|-------------|
| Overview | Portfolio metrics, equity chart, recent trades |
| Portfolio | Open positions, monthly P&L progress |
| Orders | Full order history |
| Live Signals | 370+ stock market scanner, top 20 winners |
| Indicators | Deep analysis — RSI, MACD, BB, EMA charts |
| Strategy | Signal weights, risk controls, execution settings |
| Manual Trade | Place orders manually |
| Engine Logs | Full audit trail |

---

## 🎯 Trading Strategy

| Indicator | Weight | Signal |
|-----------|--------|--------|
| RSI (14) | 25% | Oversold/Overbought |
| MACD (12,26,9) | 25% | Crossover + Histogram |
| Bollinger Bands | 20% | Band position |
| EMA 50/200 | 15% | Trend direction |
| News Sentiment | 10% | Positive/Negative |
| Fundamentals | 5% | P/E, EPS |

**Minimum composite score to trade: 70/100**

---

## 🛡️ Risk Controls

- Stop Loss: 5% (auto-set after every buy)
- Take Profit: 8%
- Max position size: 20% of free cash
- Max concurrent positions: 6
- Monthly circuit breaker: -8%
- Weekly trade limit: 2 trades

---

## 📦 Tech Stack

- **Backend:** Python, FastAPI, uvicorn
- **Frontend:** HTML/CSS/JS, Chart.js
- **Trading:** Trade 212 REST API v0
- **Hosting:** Vercel (frontend) + local PC (backend)
- **Data:** Yahoo Finance

---

## ⚠️ Disclaimer

This is for educational purposes only. Always start with paper/demo trading. Never risk money you can't afford to lose.

---

*Built with ❤️ by RaanuTradingBot*
